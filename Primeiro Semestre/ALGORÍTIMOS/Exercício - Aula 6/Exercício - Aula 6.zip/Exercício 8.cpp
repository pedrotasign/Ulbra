#include <iostream>;
#include <stdio.h>;
#include <locale.h>; // biblioteca para acentua��o.

//As ma��s custam R$ 1,30 cada se forem compradas menos de uma d�zia, e
//R$ 1,00 se forem compradas pelo menos 12. Escreva um algoritmo que leia o
//n�mero de ma��s compradas, calcule e escreva o custo total da compra.

int main()
{
	setlocale(LC_ALL, "Portuguese");
	float macas, custo, total;
	printf ("informe o numero de ma��s compradas: ");
	scanf ("%f", &macas);
	if (macas<12)
		custo= macas*1,30;
		printf ("custo das ma��s �: %f\n", custo);
		
return 0;		
}

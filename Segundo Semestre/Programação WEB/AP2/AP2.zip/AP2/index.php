<?php
    session_start();

    $requestMethod = $_SERVER['REQUEST_METHOD'];//get, post, put e delete
    $local = $_SERVER['SCRIPT_NAME']; //pw\AP2\index.php
    $uri = $_SERVER['PHP_SELF']; //pw\AP2\index.php + o que tiver além do index.php
    $rout = str_replace($local, '', $uri); //suprime pw\AP2\index.php e mostra o que estiver além

    $uriSegments = explode('/', $rout);

    if(isset($uriSegments[1])){
        $controller = $uriSegments[1];
        switch($controller){
            case 'contacts':
                require_once('controllers/ContactController.php');
                $Contact = new ContactController();
                switch($requestMethod){
                    case 'GET':
                        if(isset($uriSegments[2]) && $uriSegments[2]!= ''){
                            $Contact -> listContact($uriSegments[2]);
                        }else{
                            $Contact -> listContacts();
                        }
                    break;
                    case 'POST':
                        $Contact -> insertContact();
                    break;
                    case 'PUT':
                        $Contact -> updateContact($uriSegments[2]);
                    break;
                    case 'DELETE':
                        $Contact -> deleteContact($uriSegments[2]);
                    break;
                }
            break;

            case 'users':
                require_once('controllers/UserController.php');
                $Users = new UserController();
                switch($requestMethod){
                    case 'GET':
                        if(isset($uriSegments[2]) && $uriSegments[2] == 'login' ){
                            if(!isset($uriSegments[3]) || $uriSegments[3] = ''){
                               $Users -> login();
                                
                            }
                            
                        }
                    break;
                }

        }    
    } 

?>
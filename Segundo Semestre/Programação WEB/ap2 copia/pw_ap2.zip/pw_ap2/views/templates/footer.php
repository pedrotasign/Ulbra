            </article>

        </section>
    </div>
<footer>
    
    <a href="adm/index.php">Área Administrativa</a>
</footer>
</body>

</html>
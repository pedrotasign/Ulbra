            </article>

        </section>
    </div>
<footer>
    <p>Copyright &copy; W3Schools.com</p>
    <a href="../index.php">Home</a>
</footer>
</body>

</html>